import { toUpperCase, getApi } from '../app/Utils'


describe('Utils test', () => {
  beforeEach(() => {
    global.fetch = jest.fn()
  })
  afterEach(() => {
    // jest.clearAllMocks()
  })
  // it('should transform uppercase', () => {
  //   const str = toUpperCase('abc')
  //   expect(str).toBe('ABC')
  // })

  // it('should not transform uppercase', () => {
  //   const str = toUpperCase('ksksk', false)
  //   expect(str).not.toBe('KSKSK')
  // })

  // it('should called api', () => {
  //   getApi()
  //   expect(global.fetch).toBeCalled()
  // })

  it('should called api', () => {
    getApi()
    expect(global.fetch).toBeCalled()
  })
})